//
//  DataModel.swift
//  NewNotificationProject1
//
//  Created by Nivedha Moorthy on 23/06/25.
//

import Foundation

struct dataModel {
    
    var title: String
    var dueTime: Date
    var isCompleted: Bool
}
