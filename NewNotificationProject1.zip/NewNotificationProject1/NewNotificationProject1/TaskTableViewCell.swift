//
//  TableViewCell.swift
//  NewNotificationProject1
//
//  Created by Nivedha Moorthy on 23/06/25.
//

import UIKit

class TaskTableViewCell: UITableViewCell {
    
    @IBOutlet weak var dueDateLabel: UILabel!
    @IBOutlet weak var titleLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        print("Cell Loaded")
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
       
    }
    func configure(task: dataModel) {
        titleLabel.text = task.title
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM d, h:mm a"
        dueDateLabel.text = formatter.string(from: task.dueTime)
    }
    
}
