//
//  ViewController.swift
//  NewNotificationProject1
//
//  Created by Nivedha Moorthy on 23/06/25.
//

import UIKit
import UserNotifications
import CoreData

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var TableViewList: UITableView!
    
    var tasks: [dataModel] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        loadTasks()
        UNUserNotificationCenter.current().delegate = self
        TableViewList.register(UINib(nibName: "TaskTableViewCell", bundle: nil), forCellReuseIdentifier: "TaskTableViewCell")
        TableViewList.dataSource = self
        TableViewList.delegate = self
        requestNotificationPermission()
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addTask))
        
    }
    
    func loadTasks() {
        let request: NSFetchRequest<Entity> = Entity.fetchRequest()
        if let savedTasks = try? CoreDataManager.shared.context.fetch(request) {
            self.tasks = savedTasks.map {
                dataModel(title: $0.title ?? "", dueTime: $0.dueDate ?? Date(), isCompleted: $0.isCompleted)
            }
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tasks.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let task = tasks[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "TaskTableViewCell",for: indexPath) as! TaskTableViewCell
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM d, h:mm a"
        cell.titleLabel.text = "\(task.title)"
        cell.dueDateLabel.text =  formatter.string(from: task.dueTime)
        cell.accessoryType = task.isCompleted ? .checkmark : .none
        return cell
    }
    
    func tableView(_ tableView: UITableView,
                   trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath)
        -> UISwipeActionsConfiguration? {
        
            var task = tasks[indexPath.row]

    
        let completeAction = UIContextualAction(style: .normal, title: task.isCompleted ? "Undo" : "Complete") { _, _, completion in
            task.isCompleted.toggle()
            let title = task.title
            if let matched = try? CoreDataManager.shared.context.fetch(Entity.fetchRequest()) as? [Entity],
               let taskToUpdate = matched.first(where: { $0.title == title }) {
                taskToUpdate.isCompleted = task.isCompleted
                CoreDataManager.shared.saveContext()
            }

            self.loadTasks()
            tableView.reloadRows(at: [indexPath], with: .automatic)
            completion(true)
        }
        completeAction.backgroundColor = .systemGreen

        let deleteAction = UIContextualAction(style: .destructive, title: "Delete") { _, _, completion in
            let deletedTask = self.tasks[indexPath.row]
            self.tasks.remove(at: indexPath.row)

            let fetchRequest: NSFetchRequest<Entity> = Entity.fetchRequest()
            if let savedTasks = try? CoreDataManager.shared.context.fetch(fetchRequest) {
                if let match = savedTasks.first(where: { $0.title == deletedTask.title }) {
                    CoreDataManager.shared.context.delete(match)
                    CoreDataManager.shared.saveContext()
                }
            }

            self.TableViewList.deleteRows(at: [indexPath], with: .fade)
            completion(true)
        }

        return UISwipeActionsConfiguration(actions: [deleteAction, completeAction])
    }
    
    @objc func addTask() {
            let alert = UIAlertController(title: "New Task", message: "\n\n\n\n\n", preferredStyle: .alert)

            alert.addTextField { textField in
                textField.placeholder = "Enter task title"
            }

            // Add DatePicker to alert
            let datePicker = UIDatePicker()
            datePicker.datePickerMode = .dateAndTime
            datePicker.frame = CGRect(x: 10, y: 60, width: 250, height: 140)
            alert.view.addSubview(datePicker)

            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
            alert.addAction(UIAlertAction(title: "Add", style: .default, handler: { _ in
                guard let title = alert.textFields?.first?.text, !title.isEmpty else { return }
                
                let entity = Entity(context: CoreDataManager.shared.context)
                entity.title = title
                entity.dueDate = datePicker.date
                entity.isCompleted = false
                CoreDataManager.shared.saveContext()

               
                self.loadTasks()
                self.TableViewList.reloadData()
                
                let newTask = dataModel(title: title, dueTime: datePicker.date, isCompleted: false)
                self.scheduleNotification(for: newTask)
            }))

            present(alert, animated: true)
        }
    
    func requestNotificationPermission() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert,.sound]) { granted,_ in
            DispatchQueue.main.async {
                if !granted {
                    print("✅ Notifications allowed")
                }else {
                    self.showNotificationSettingsAlert()
                }
            }
        }
        
    }
    
    func showNotificationSettingsAlert() {
        let alert = UIAlertController(
            title: "Enable Notifications",
            message: "To get task reminders, please allow notifications in Settings.",
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        alert.addAction(UIAlertAction(title: "Open Settings", style: .default, handler: { _ in
            if let settingsURL = URL(string: UIApplication.openSettingsURLString) {
                UIApplication.shared.open(settingsURL)
            }
        }))
        self.present(alert, animated: true)
    }
    func scheduleNotification(for task: dataModel) {
        let center = UNUserNotificationCenter.current()
        let notificationTime = task.dueTime.addingTimeInterval(-600)
        if notificationTime < Date() {
            return
        }

        let content = UNMutableNotificationContent()
        content.title = "Upcoming Task"
        content.body = "‘\(task.title)’ is due in 10 minutes."
        content.sound = .default

        let triggerDate = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: notificationTime)
        let trigger = UNCalendarNotificationTrigger(dateMatching: triggerDate, repeats: false)

        let request = UNNotificationRequest(
            identifier: UUID().uuidString,
            content: content,
            trigger: trigger
        )

        center.add(request) { error in
            if let error = error {
                print("Notification scheduling failed: \(error)")
            } else {
                print("Notification scheduled for \(task.title)")
            }
        }
    }
    
    
}
extension ViewController: UNUserNotificationCenterDelegate {
    func userNotificationCenter(_ center: UNUserNotificationCenter,
        willPresent notification: UNNotification,
        withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.banner, .sound])
    }
}

