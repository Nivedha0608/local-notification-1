//
//  NewNotificationProject1Tests.swift
//  NewNotificationProject1Tests
//
//  Created by Nivedha Moorthy on 23/06/25.
//

import Testing
@testable import NewNotificationProject1

struct NewNotificationProject1Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
